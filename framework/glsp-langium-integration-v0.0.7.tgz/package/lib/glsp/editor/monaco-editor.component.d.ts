import { MonacoEditorLanguageClientWrapper, WrapperConfig } from 'monaco-editor-wrapper';
import React from 'react';
import { MessageConnection } from 'vscode-languageclient';
export type MonacoEditorWrapperProps = {
    /** Provides various static configs for the `MonacoEditorLanguageClientWrapper` and its wrapped `EditorApp` */
    wrapperConfig: WrapperConfig;
    /** Allows access to the `MonacoEditorLanguageClientWrapper` and `setHeight` on initial load */
    onLoad: (wrapper: MonacoEditorLanguageClientWrapper, setHeight: React.Dispatch<React.SetStateAction<string>>) => void;
    /** Allows external access to the information captured inside the React component on clicking outside */
    onSubmit: (text: string, ast: any) => void;
    /** Promise of the `MessageConnection` with the Langium LSP needed to receive specific AST updates from Langium */
    connection: Promise<MessageConnection>;
    /** The initial height */
    initHeight: string;
};
export declare const MonacoEditorWrapper: ({ wrapperConfig, onLoad, onSubmit, connection, initHeight }: MonacoEditorWrapperProps) => React.JSX.Element;
//# sourceMappingURL=monaco-editor.component.d.ts.map