/** @jsx svg */
import { GLabel, RenderingContext, ShapeView } from '@eclipse-glsp/client';
import { VNode } from 'snabbdom';
/**
 * A custom label view that injects html elements into the svg context and uses them as anchors
 * to attach Monaco editors to.
 */
export declare class MonacoLabelView extends ShapeView {
    private monacoContainer;
    private monacoEditorSizeService;
    render(label: Readonly<GLabel>, context: RenderingContext): VNode | undefined;
}
//# sourceMappingURL=monaco-label.view.d.ts.map