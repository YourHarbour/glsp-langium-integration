import { EditorAppConfig, ExtensionConfig, WrapperConfig } from 'monaco-editor-wrapper';
import { Logger } from 'monaco-languageclient/tools';
import { LangiumConfigParams, LangiumInitConfigParams } from '../../common/types/types.js';
/**
 * Provides methods for creating Monaco editor wrapper configs, either for one of many editors
 * or for an initial editor that starts all the important services in the background.
 *
 * Must be implemented by the application and bound like this:
 * `bind(LANGIUM_COMPONENT_TYPES.MonacoWrapperConfigService).to(MyMonacoWrapperConfigService);`
 */
export declare abstract class MonacoWrapperConfigService {
    /**
     * Creates a `WrapperConfig` fit for every editor.
     *
     * @param params Contains information about containers and the content to render
     */
    createLangiumGlobalConfig(params: LangiumConfigParams): WrapperConfig;
    /**
     * Creates a `WrapperConfig` with additional configurations that cause the creation
     * and registration of services, which are then available for all editors, but should
     * only be created once. Therefore, it should only be created for a special init editor.
     *
     * @param params Contains information about containers and the content to render
     */
    createLangiumInitConfig(params: LangiumInitConfigParams): WrapperConfig;
    /** Provides the grammar-specific extension config */
    protected abstract getExtensionConfig(): ExtensionConfig;
    /** Provides the grammar-specific document selectors */
    protected abstract getDocumentSelectors(): string[];
    /** Provides the options governing the layout and features of the editor */
    protected getEditorOptions(overflowContainer?: HTMLElement): EditorAppConfig['editorOptions'];
    /** Starts the necessary Monaco workers */
    protected configureMonacoWorkers(logger?: Logger): void;
}
//# sourceMappingURL=monaco-wrapper-config.service.d.ts.map