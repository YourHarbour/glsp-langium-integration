import { GLSPAbstractUIExtension, GLSPActionDispatcher } from '@eclipse-glsp/client';
import { MonacoLabelConfig } from '../../common/types/types.js';
import { LangiumWorkerHandler } from '../worker/langium-worker.handler.js';
import { MonacoEditorCreationService } from './monaco-editor-creation.service.js';
import { MonacoEditorSizeService } from './monaco-editor-size.service.js';
import { MonacoSubmitService } from './monaco-submit.service.js';
import { MonacoWrapperConfigService } from './monaco-wrapper-config.service.js';
/**
 * Provides APIs to create and manage Monaco editors.
 * This circumvents the need of re-creating editors by instead attaching and detaching them from
 * their desired place in the DOM-tree, keeping them rendered inside an invisible container
 * in the meantime.
 *
 * If a change in behaviour is desired, this should in most cases not happen via
 * extension of this class, but rather the custom implementation of its injected
 * components. Nonetheless, in case of override, it must be rebound like this:
 * `bind(LANGIUM_COMPONENT_TYPES.MonacoContainerUIExtension).to(MyMonacoContainerUIExtension).inSingletonScope();`
 */
export declare class MonacoContainerUIExtension extends GLSPAbstractUIExtension {
    protected actionDispatcher: GLSPActionDispatcher;
    protected langiumWorkerHandler: LangiumWorkerHandler;
    protected monacoEditorSizeService: MonacoEditorSizeService;
    protected monacoSubmitService: MonacoSubmitService;
    protected monacoWrapperConfigService: MonacoWrapperConfigService;
    protected monacoEditorCreationService: MonacoEditorCreationService;
    protected elements: Record<string, HTMLElement>;
    protected preCreatedElements: Record<string, HTMLElement>;
    protected elementValidationCallbacks: Record<string, () => void>;
    protected elementSetHeightCallbacks: Record<string, (height: string) => void>;
    id(): string;
    containerClass(): string;
    protected initializeContents(containerElement: HTMLElement): void;
    /** Triggers the initialization */
    show(): void;
    /**
     * Allows access to an editor element using the id of the relevant label element.
     * Because this method might be called before the editors were initizalized, it just creates
     * empty containers that are filled later on.
     *
     * @param labelId The id corresponding to the required editor
     * @returns The editor's container element
     */
    getElement(labelId: string): HTMLElement;
    /**
     * Returns an element back to the extension, i.e. detaching it from its place-of-use and
     * attaching it to the invisble container for safe-keeping.
     *
     * @param labelId The id of the element to return
     */
    returnElement(labelId: string): void;
    /**
     * Activates the validation callbacks of each editor, which each then communicates with Langium.
     */
    revalidateEditors(): void;
    /**
     * Resizes the container of an editor using the `MonacoEditorSizeService` using the label elements id.
     */
    resizeEditor(labelId: string): void;
    /**
     * Creates editor elements based on the label element's id, its containing node's id,
     * the type to use as a file ending to identify the grammar to use and the initial text.
     */
    createElements(labels: MonacoLabelConfig[]): void;
    /** Creates a complete editor element, both container and content */
    protected createEditor(label: MonacoLabelConfig, init?: boolean): HTMLDivElement;
    /** Create a `<div>` to serve as a container for an editor */
    protected createEditorContainer(labelId: string): HTMLDivElement;
    /**
     * Fill the given container with a proper Monaco editor using a separate React instance.
     *
     * @param container The container to fill
     * @param label The relevant information about the editor to create
     * @param init Whether to create a special init editor that starts various Monaco services
     */
    protected createEditorContent(container: HTMLElement, label: MonacoLabelConfig, init?: boolean): void;
}
//# sourceMappingURL=monaco-container.extension.d.ts.map