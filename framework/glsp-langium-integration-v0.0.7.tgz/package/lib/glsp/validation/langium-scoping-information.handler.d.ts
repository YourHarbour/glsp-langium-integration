import { Action, GLSPActionDispatcher, GModelRootSchema, IActionHandler, ICommand } from '@eclipse-glsp/client';
import { LangiumWorkerHandler } from '../worker/langium-worker.handler.js';
import { GenerateLangiumScopingInformationAction, SetLangiumScopingInformationAction } from './validation.action.js';
/**
 * Handles `SetLangiumScopingInformationAction` and `GenerateLangiumScopingInformationAction` to inform the
 * Langium Language Server of relevant scoping information. If custom client-side scoping information is required,
 * typically only `generateScopingInformation` needes to be overriden.
 *
 * To ensure the aforementioned actions are always handled, a default implementation is already bound and custom
 * implementation must be rebound like this:
 * `rebind(LANGIUM_COMPONENT_TYPES.LangiumScopingInformationHandler).to(MyLangiumScopingInformationHandler)`
 */
export declare abstract class LangiumScopingInformationHandler<T = any> implements IActionHandler {
    protected actionDispatcher: GLSPActionDispatcher;
    protected langiumWorkerHandler: LangiumWorkerHandler;
    handle(action: Action): ICommand | Action | void;
    protected doOnSet(action: SetLangiumScopingInformationAction): Promise<void>;
    protected doOnGenerate(action: GenerateLangiumScopingInformationAction): Promise<void>;
    /**
     * If the server does not provide the information, the scoping information to inject into Langium must be created on the client.
     *
     * @param model The graph model to use as basis for the scoping information
     */
    protected abstract generateScopingInformation(model: GModelRootSchema): T;
}
/** A default implementation to use, if client-generated scoping information is not required */
export declare class DefaultLangiumScopingInformationHandler extends LangiumScopingInformationHandler {
    protected generateScopingInformation(model: GModelRootSchema): {};
}
//# sourceMappingURL=langium-scoping-information.handler.d.ts.map