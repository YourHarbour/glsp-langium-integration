import { Action, GLSPActionDispatcher, IActionHandler, ICommand, Marker } from '@eclipse-glsp/client';
import { ValidationResult } from '../../common/types/types.js';
import { MonacoContainerUIExtension } from '../editor/monaco-container.extension.js';
import { LangiumWorkerHandler } from '../worker/langium-worker.handler.js';
import { LangiumScopingInformationSuccessAction } from './validation.action.js';
/**
 * Handles `LangiumScopingInformationSuccessAction` to trigger a batch validation using the Langium Language Server.
 * If validation should also occur on other actions, override `handleCustomAction`.
 *
 * While multiple action handlers for the same action could exist, to prevent any unexpected behaviour, rebind
 * this component on extension like this:
 * `rebind(LANGIUM_COMPONENT_TYPES.LangiumValidationHandler).to(MyLangiumValidationHandler)`
 */
export declare class LangiumValidationHandler implements IActionHandler {
    protected langiumWorkerHandler: LangiumWorkerHandler;
    protected actionDispatcher: GLSPActionDispatcher;
    protected monacoContainer: MonacoContainerUIExtension;
    constructor(langiumWorkerHandler: LangiumWorkerHandler);
    handle(action: Action): ICommand | Action | void;
    /**
     * In virtually every case, it makes sense to revalidate the model elements if the relevant scoping information has been updated.
     *
     * @param action `LangiumScopingInformationSuccessAction`
     */
    protected handleLangiumScopingInformationSuccessAction(action: LangiumScopingInformationSuccessAction): ICommand | Action | void;
    /**
     * In the event that validation should be triggered on an action different than an update of the scoping information,
     * this needs to be implemented manually.
     *
     * @param action Any configured action
     */
    protected handleCustomAction(action: Action): ICommand | Action | void;
    protected handleLangiumValidationResponse(validationResults: ValidationResult[]): void;
    protected generateMarkers(diagnostics: ValidationResult[]): Marker[];
}
//# sourceMappingURL=langium-validation.handler.d.ts.map