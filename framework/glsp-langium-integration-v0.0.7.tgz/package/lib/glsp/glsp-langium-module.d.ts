import { ContainerConfiguration, FeatureModule } from '@eclipse-glsp/client';
import { Container } from 'inversify';
/**
 * A module registering the default setup of the services, handlers, and actions necessary for the integration to work.
 * As some services are entirely dependent on the specific application, they still have to be registered manually.
 */
export declare const GlspLangiumModule: FeatureModule;
export declare function initializeLangiumDiagramContainer(container: Container, ...containerConfiguration: ContainerConfiguration): Container;
//# sourceMappingURL=glsp-langium-module.d.ts.map