/**
 * An object containing all the symbols of the newly created services and handlers that are used
 * to register and access them using `inversify`.
 */
export declare const LANGIUM_COMPONENT_TYPES: {
    LangiumScopingInformationHandler: symbol;
    LangiumValidationHandler: symbol;
    LangiumWorkerHandler: symbol;
    LangiumWorkerFactory: symbol;
    MonacoContainerUIExtension: symbol;
    MonacoEditorSizeService: symbol;
    MonacoSubmitService: symbol;
    MonacoWrapperConfigService: symbol;
    MonacoEditorCreationService: symbol;
};
//# sourceMappingURL=langium-component-types.d.ts.map