export * from './langium-component-types.js';
//# sourceMappingURL=index.d.ts.map