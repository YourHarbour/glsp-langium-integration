import { Action, IActionHandler, ICommand } from '@eclipse-glsp/client';
import { MessageConnection } from 'vscode-languageclient/browser.js';
import { LangiumWorkerFactory } from './langium-worker.factory.js';
/**
 * Handles all communication with the Langium Language Server running in its own web worker. It exposes
 * APIs for other components to use, thus acting as an adapter or proxy.
 *
 * If this class is extended, it must also be rebound like this:
 * `rebind(LANGIUM_COMPONENT_TYPES.LangiumWorkerHandler).to(MyLangiumWorkerHandler).inSingletonScope()`
 *
 * It is critical that this handler is registered in singleton scope.
 *
 * This handler requires a `LangiumWorkerFactory` to instantiate the worker and this is must be provided
 * by the application module like this:
 * `bind(LANGIUM_COMPONENT_TYPES.LangiumWorkerFactory).to(MyLangiumWorkerFactory).inSingletonScope()`
 */
export declare class LangiumWorkerHandler implements IActionHandler {
    protected langiumWorkerFactory: LangiumWorkerFactory;
    protected _worker: Worker;
    protected _connection: MessageConnection;
    protected workerResolvers: ((value: Worker) => void)[];
    protected connectionResolvers: ((value: MessageConnection) => void)[];
    handle(action: Action): ICommand | Action | void;
    /** The `MessageConnection` as a promise as it may not be initialized yet */
    get connection(): Promise<MessageConnection>;
    /** The underlying `Worker` as a promise as it may not be initialized yet */
    get worker(): Promise<Worker>;
}
//# sourceMappingURL=langium-worker.handler.d.ts.map