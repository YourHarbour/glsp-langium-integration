/**
 * This abstract class provides an extensible service used to create a Langium LSP server for `LangiumWorkerHandler`.
 *
 * It must be bound using the following code:
 * `bind(LANGIUM_COMPONENT_TYPES.LangiumWorkerFactory).to(MyLangiumWorkerFactory)`
 */
export declare abstract class LangiumWorkerFactory {
    abstract create(): Worker;
}
//# sourceMappingURL=langium-worker.factory.d.ts.map