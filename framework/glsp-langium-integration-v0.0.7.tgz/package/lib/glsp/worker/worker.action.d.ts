import { Action } from '@eclipse-glsp/client';
/** An action simply to inform `LangiumWorkerHandler` that GLSP has loaded and it can now create and connect the Langium LSP worker */
export interface LangiumWorkerStartupAction extends Action {
    kind: typeof LangiumWorkerStartupAction.KIND;
}
export declare namespace LangiumWorkerStartupAction {
    const KIND = "LangiumWorkerStartupAction";
    function is(object: unknown): object is LangiumWorkerStartupAction;
    function create(options?: Omit<LangiumWorkerStartupAction, 'kind'>): LangiumWorkerStartupAction;
}
//# sourceMappingURL=worker.action.d.ts.map