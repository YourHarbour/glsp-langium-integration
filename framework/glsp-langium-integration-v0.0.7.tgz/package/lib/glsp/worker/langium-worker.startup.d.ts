import { IActionDispatcher, IDiagramStartup } from '@eclipse-glsp/client';
/** This class simply dispatches an action to communicate the successful startup of GLSP, and thus triggers the creation of the Langium LSP worker */
export declare class LangiumWorkerStartup implements IDiagramStartup {
    protected actionDispatcher: IActionDispatcher;
    postRequestModel(): Promise<void>;
}
//# sourceMappingURL=langium-worker.startup.d.ts.map