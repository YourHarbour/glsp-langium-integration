export * from './langium-ast.util.js';
//# sourceMappingURL=index.d.ts.map