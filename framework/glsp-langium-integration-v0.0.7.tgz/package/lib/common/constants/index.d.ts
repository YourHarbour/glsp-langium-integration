export * from './langium-message-types.js';
export * from './langium-uri-regex.js';
//# sourceMappingURL=index.d.ts.map