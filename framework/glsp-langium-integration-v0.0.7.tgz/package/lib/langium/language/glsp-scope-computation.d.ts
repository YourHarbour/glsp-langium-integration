import { AstNodeDescription, DefaultScopeComputation, LangiumCoreServices, LangiumDocument } from 'langium';
import { GlspServices } from '../../common/types/types.js';
/**
 * The `ScopeComputation` is responsible for providing `AstNodeDescription`s for the dynamic elements,
 * i.e. non-keyword elements of the grammar.
 *
 * For the purposes of our integration, we override `computeExports` to also inject our external nodes
 * to make them available in the scope. Those elements must then be matched by the `Linker` to ensure
 * the references can be resolved.
 */
export declare class GlspScopeComputation extends DefaultScopeComputation {
    protected glsp: GlspServices;
    constructor(services: LangiumCoreServices);
    collectExportedSymbols(document: LangiumDocument): Promise<AstNodeDescription[]>;
    /**
     * By default, we expect the scoping information to follow a certain format, i.e. a simple
     * object, where the name of the type in the grammar identifies an array of scoping information elements.
     */
    protected getCustomNodes(document: LangiumDocument): AstNodeDescription[];
}
//# sourceMappingURL=glsp-scope-computation.d.ts.map