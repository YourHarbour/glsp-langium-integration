import { AstNode, AstNodeDescription, DefaultLinker, LangiumCoreServices } from 'langium';
import { GlspServices } from '../../common/types/types.js';
/**
 * The `Linker` is responsible for resolving the references in a `LangiumDocument`.
 *
 * The critical part for our integration is to override `loadAstNode` as this tries to lookup the
 * nodes, as defined by a `AstNodeDescription`. The descriptions we injected in the `ScopeComputation`
 * need to resolve to an actual `AstNode` object, though it can be minimal in scope.
 */
export declare class GlspLinker extends DefaultLinker {
    protected glsp: GlspServices;
    constructor(services: LangiumCoreServices);
    protected loadAstNode(nodeDescription: AstNodeDescription): AstNode | undefined;
}
//# sourceMappingURL=glsp-linker.d.ts.map