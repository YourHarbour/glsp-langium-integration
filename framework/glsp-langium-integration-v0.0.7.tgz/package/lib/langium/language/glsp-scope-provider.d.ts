import { DefaultScopeProvider, LangiumCoreServices, LangiumDocument, ReferenceInfo, Scope } from 'langium';
import { GlspServices } from '../../common/types/types.js';
/**
 * The `ScopeProvider` is responsible to actually provide a `Scope` for a given context, not only `AstNodeDescription` elements.
 * It has thus access to more granular information about the context in question.
 */
export declare class GlspScopeProvider extends DefaultScopeProvider {
    protected glsp: GlspServices;
    constructor(services: LangiumCoreServices);
    getScope(context: ReferenceInfo): Scope;
    /**
     * This method allows easy access to all context information, including the id, in order to allow
     * context-aware scoping.
     *
     * @param context Information about a cross-reference
     * @param document The document using the reference
     * @param id The id extracted from the document's URI
     */
    protected getCustomScope(context: ReferenceInfo, document: LangiumDocument, id: string): Scope | void;
}
//# sourceMappingURL=glsp-scope-provider.d.ts.map