import { GlspLangiumSharedServices } from '../../common/types/types.js';
/** Listens to batch validation requests from the GLSP client */
export declare class BatchValidationListener {
    protected services: GlspLangiumSharedServices;
    constructor(services: GlspLangiumSharedServices);
    listen(): Promise<void>;
}
//# sourceMappingURL=batch-validation-listener.d.ts.map