import { AstNode, LangiumDocument } from 'langium';
import { GlspLangiumSharedServices } from '../../common/types/types.js';
/** Sends a batch validation response to the GLSP client once all documents have been validated */
export declare class BatchValidationHandler {
    protected services: GlspLangiumSharedServices;
    constructor(services: GlspLangiumSharedServices);
    onBuildValidated(docs: LangiumDocument<AstNode>[]): void;
}
//# sourceMappingURL=batch-validation-handler.d.ts.map