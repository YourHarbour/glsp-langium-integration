import { GlspLangiumSharedServices } from '../../common/types/types.js';
/** This class receives the scoping information from the GLSP client and provides access to it */
export declare class ScopingInformationListener<T = any> {
    protected services: GlspLangiumSharedServices;
    scopingInformation: T;
    constructor(services: GlspLangiumSharedServices);
    listen(): Promise<void>;
    protected handleInformation(data: T): void;
}
//# sourceMappingURL=validation-information-listener.d.ts.map