import { MessageConnection } from 'vscode-languageserver/browser.js';
import { GlspLangiumSharedServices } from '../../common/types/types.js';
/** A proxy that provides access to the `MessageConnection` established with the GLSP client */
export declare class GlspConnection {
    protected services: GlspLangiumSharedServices;
    protected _connection: MessageConnection;
    protected connectionResolvers: ((value: MessageConnection) => void)[];
    constructor(services: GlspLangiumSharedServices);
    init(): void;
    get connection(): Promise<MessageConnection>;
}
//# sourceMappingURL=glsp-connection.d.ts.map