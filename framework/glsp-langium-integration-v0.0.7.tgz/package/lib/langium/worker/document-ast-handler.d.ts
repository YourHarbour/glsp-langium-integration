import { AstNode, LangiumDocument } from 'langium';
import { GlspLangiumSharedServices } from '../../common/types/types.js';
/** Sends an AST of a `LangiumDocument` to the GLSP client using an id once a document has been validated  */
export declare class DocumentAstHandler {
    protected services: GlspLangiumSharedServices;
    constructor(services: GlspLangiumSharedServices);
    onDocumentValidated(doc: LangiumDocument<AstNode>): void;
    /** Since the complete AST contains technical Langium details and circular references, it is minimized before communication with the client */
    protected extractMinimalAst(value: any): any;
}
//# sourceMappingURL=document-ast-handler.d.ts.map