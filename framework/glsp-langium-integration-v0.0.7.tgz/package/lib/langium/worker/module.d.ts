import { LangiumDefaultCoreServices, Module } from 'langium';
import { DefaultModuleContext, DefaultSharedModuleContext, LangiumLSPServices, LangiumServices, LangiumSharedServices } from 'langium/lsp';
import { GlspLangiumSharedGlspServices, GlspLangiumSharedServices, GlspServiceInjectors } from '../../common/types/types.js';
/** Creates an dependency injection module of the shared services that contains our custom services */
export declare function createGlspSharedModule(context: DefaultSharedModuleContext, glspServices?: GlspServiceInjectors): Module<GlspLangiumSharedServices, LangiumSharedServices & GlspLangiumSharedGlspServices>;
/** Creates an dependency injection module of language-specific services that contains our custom services */
export declare function createGlspModule(context: DefaultModuleContext): Module<LangiumServices, LangiumDefaultCoreServices & LangiumLSPServices>;
//# sourceMappingURL=module.d.ts.map