import { GlspLangiumSharedServices } from '../../common/types/types.js';
/** This class provides the type names of the external elements, which must correspond to the types defined in the grammar */
export declare class ExternalNodeInformationService {
    protected services: GlspLangiumSharedServices;
    constructor(services: GlspLangiumSharedServices);
    getExternalNodeNames(): string[];
}
//# sourceMappingURL=external-node-information-service.d.ts.map