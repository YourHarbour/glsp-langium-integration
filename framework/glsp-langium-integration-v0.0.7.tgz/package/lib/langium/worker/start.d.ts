import { GlspLangiumSharedServices } from '../../common/types/types.js';
/** Registers our custom services in addition to the default services */
export declare function startGlspLanguageServer(services: GlspLangiumSharedServices): void;
//# sourceMappingURL=start.d.ts.map